(function (exports) {
    'use strict';

    const getStore = revenge.discord.flux.getStore;
    const getModules = revenge.modules.finders.getModules;
    const withProps = revenge.modules.finders.filters.withProps;
    const before = revenge.patcher.before;
    const instead = revenge.patcher.instead;

    const EMOJI_SIZE = 48;
    const FORCE_SPOOF = false;
    const CUSTOM_EMOJI = /<(a?):([A-Za-z0-9_]+):(\d+)>/g;

    let emojiStore;
    let selectedGuildStore;
    let userStore;

    function hasNativeEmojiPrivilege() {
        if (FORCE_SPOOF) return false;
        const user = userStore && userStore.getCurrentUser && userStore.getCurrentUser();
        const premiumType = user && user.premiumType;
        return typeof premiumType === 'number' && premiumType > 0;
    }

    function invalidEmojiIds(message) {
        const ids = new Set();
        const items = message.invalidEmojis || [];
        for (const item of items) {
            if (typeof item === 'string') ids.add(item);
            else if (item && typeof item === 'object' && typeof item.id === 'string') ids.add(item.id);
        }
        return ids;
    }

    function cdnUrl(id, name, animated) {
        const ext = animated ? 'gif' : 'webp';
        return `https://cdn.discordapp.com/emojis/${id}.${ext}?size=${EMOJI_SIZE}&quality=lossless&name=${encodeURIComponent(name)}`;
    }

    function shouldSpoof(id, tokenAnimated, invalidIds) {
        if (invalidIds.has(id)) return true;

        const emoji = emojiStore && emojiStore.getCustomEmojiById
            ? emojiStore.getCustomEmojiById(id)
            : undefined;
        if (!emoji) return true;

        const guildId = selectedGuildStore && selectedGuildStore.getGuildId
            ? selectedGuildStore.getGuildId()
            : undefined;
        if (emoji.guildId && guildId && emoji.guildId !== guildId) return true;

        return tokenAnimated || !!emoji.animated;
    }

    function modifyMessage(message) {
        if (!message || typeof message.content !== 'string') return;
        if (hasNativeEmojiPrivilege()) return;

        CUSTOM_EMOJI.lastIndex = 0;
        if (!CUSTOM_EMOJI.test(message.content)) {
            CUSTOM_EMOJI.lastIndex = 0;
            return;
        }
        CUSTOM_EMOJI.lastIndex = 0;

        const invalidIds = invalidEmojiIds(message);
        message.content = message.content.replace(
            CUSTOM_EMOJI,
            function (whole, animatedFlag, name, id) {
                const tokenAnimated = animatedFlag === 'a';
                if (!shouldSpoof(id, tokenAnimated, invalidIds)) return whole;
                return cdnUrl(id, name, tokenAnimated);
            },
        );
        message.invalidEmojis = [];
    }

    exports.default = plugin({
        start({ cleanup }) {
            cleanup(
                getStore('EmojiStore', store => { emojiStore = store; }),
                getStore('SelectedGuildStore', store => { selectedGuildStore = store; }),
                getStore('UserStore', store => { userStore = store; }),
            );

            cleanup(
                getModules(
                    withProps('canUseEmojisEverywhere', 'canUseAnimatedEmojis'),
                    nitroChecks => {
                        cleanup(
                            instead(nitroChecks, 'canUseEmojisEverywhere', () => true),
                            instead(nitroChecks, 'canUseAnimatedEmojis', () => true),
                        );
                    },
                    { max: 1 },
                ),
            );

            cleanup(
                getModules(
                    withProps('sendMessage', 'receiveMessage'),
                    messageModule => {
                        cleanup(
                            before(messageModule, 'sendMessage', args => {
                                modifyMessage(args[1]);
                            }),
                        );
                    },
                    { max: 1 },
                ),
            );

            cleanup(
                getModules(
                    withProps('uploadLocalFiles'),
                    uploadModule => {
                        cleanup(
                            before(uploadModule, 'uploadLocalFiles', args => {
                                const first = args[0];
                                modifyMessage(first && (first.parsedMessage || first.message));
                            }),
                        );
                    },
                    { max: 1 },
                ),
            );
        },
    });

    return exports;
})({})
